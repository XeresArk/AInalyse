
# Model Card

## Model Overview

AInalyse is an AI-driven risk & impact analysis engine designed to evaluate source-code and database changes, scan and identify across multiple microservices, components, or downstream systems may be affected.

This document describes the base model used within AInalyse implementation (e.g., via  `GeminiService.java`). The model supports text and multimodal inputs, providing generative AI capabilities.

## Base Model

**Model Name:**  Google Gemini API model
**Provider:**  Google
**Type:**  Large Language Model (LLM)
**Model:** Gemini 2.5 Flash
**Modality:**
-   Text generation
-   Multimodal reasoning

## Why This Model Was Chosen

-   **High‑quality text generation:**  Gemini models are optimized for natural language understanding and generation.
    
-   **Multimodal support:**  Can handle images, text, and embeddings in unified workflows.
    
-   **Strong reasoning capabilities:**  Useful for enterprise and domain‑specific tasks.
    
-   **API‑friendly:**  Integration via REST/Java SDK is straightforward.
    
-   **Scalability:**  Models can be configured at different capability levels depending on latency and cost.
    

## Known Limitations

-   **Hallucinations:**  The model may generate plausible but incorrect information, especially for factual or domain‑specific queries.
    
-   **Context length constraints:**  Long inputs require chunking or summarization.
    
-   **Non‑determinism:**  Results may vary between calls due to sampling or model updates.
    
-   **Latency:**  Larger variants may have higher response times.
    
-   **Rate limits / quota:**  API usage is subject to billing and quotas.
    

## Potential Biases

All large language models inherit biases from their training data. Known categories include:

-   **Cultural & linguistic bias:**  Stronger performance for English or widely represented cultures.
    
-   **Gender and demographic bias:**  May generate uneven or stereotyped outputs.
    
-   **Security bias:**  Over‑ or under‑restriction in safety responses.
    

## Mitigations and Best Practices

-   Add domain validation layers for responses.
    
-   Use deterministic settings (temperature ≈ 0) for factual queries.
    
-   Employ human‑in‑the‑loop review for critical outputs.
    
-   Monitor for bias or hallucinations in real‑world usage.
    
-   Log prompts/responses for quality evaluation.