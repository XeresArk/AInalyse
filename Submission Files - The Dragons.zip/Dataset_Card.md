
# Dataset Card

## Overview

This dataset description is based on the AInalyse architecture shown in the system diagram. AInalyse evaluates code changes across microservices using multiple analysers and technical metadata feeds. The dataset consists entirely of  **technical, non-personal metadata**.

----------

## Data Sources

AInalyse aggregates data from four major analysers:

### 1.  **Commit Analyser Dataset**

-   Git commit diffs for microservices/database repos
    
-   Changed files
    
-   Inline code modifications
    

### 2.  **Dependency Map Generator Dataset**

-   Precomputed dependency maps for multiple microservices
    
-   Module-to-module dependency relationships
    
-   API call graphs
    

### 3.  **Code Diff Analyser Dataset**

-   User inputted diffs for microservices/database repos
    

### 4.  **Database Analyser Dataset**

-   Database object mappings (tables, views, stored procedures)
    
-   Metadata tables
    
-   Table–module relationship metadata
    

----------

## Data Flow

1.  GitHub provides commit diffs → Commit Analyser.
    
2.  Dependency maps are fetched → Dependency Map Generator.
    
3.  Both commit diffs and dependency maps feed into prompt creation.
        
4.  A combined prompt (containing all technical inputs) is sent to Gemini.
    
5.  Gemini responds with a structured AInalyse impact analysis.
    
This means the dataset is  **multi-source and layered**, consisting of diffs, metadata maps, and DB analysis results.

----------

## Micorservices for AInalyse

For the AInalyse service to work you need existing microservices and database repositories (containing DB scripts). The sample micorservices being used by use are:

## 🧑🏻‍💼EmployeeApp
#### 🟢 Employee Info (`/api/employee/info`)

-   `GET /{id}` - Get employee details by ID.
    
-   `GET /search?department={dept}` - Search employees by department.
    
-   `GET /summary` - Get a count of active and audited employees.
    
-   `GET /findAllEmployees` - Retrieve all employees directly from the database.
    

#### 🟡 Employee Actions (`/api/employee/action`)

-   `POST /add` - Add a new employee (automatically promoted to 'Staff').
    
-   `PUT /update/{id}` - Update an existing employee's details.
    
-   `DELETE /delete/{id}` - Deactivate and delete an employee.
    

#### 🔴 Employee Admin (`/api/employee/admin`)

-   `POST /promote/{id}?newRole={role}` - Promote an employee to a new role.
    
-   `POST /deactivate/{id}` - Deactivate an employee (triggers deletion).
    
-   `GET /audit` - Retrieve a list of employees for auditing.
    

## 📂 Project Structure

-   **Controller**: Handles incoming REST requests (`EmployeeActionController`, `EmployeeAdminController`, `EmployeeInfoController`).
    
-   **Service**: Contains business logic (`EmployeeHelperService`, `EmployeeAdminService`, `EmployeeAuditService`).
    
-   **Repository**: Data access layer using Spring Data JPA (`EmployeeRepository`).
    
-   **Entities**: JPA entities representing database tables (`EmployeeEntity`).
    
-   **Config**: Application configuration (`DataSourceConfig`, `OpenApiConfig`).

## 🏢Department

####  ℹ️Department Info (`/department`)

-   `GET /info` - Returns static department information (HR, Finance, Engineering).
    

#### 👥 Employee Proxy (`/department-employee`)

_Delegates read operations to `EmployeeApp` via `DepartmentEmployeeService`._

-   `GET /employees` - Fetch employees (defaults to searching 'HR').
    
-   `GET /employee/{id}` - Get details for a specific employee by ID.
    
-   `GET /summary` - Get aggregated employee counts.
    
-   `GET /findAllEmployees` - Retrieve the full list of employees.
    

#### 🛠 Admin Proxy (`/department-employee`)

_Delegates write/admin operations to `EmployeeApp` via `DepartmentEmployeeAdminService`._

-   `GET /add?employeeJson={...}` - Add a new employee.
    
-   `GET /promote/{id}?newRole={role}` - Promote an employee to a new role.
    
-   `GET /deactivate/{id}` - Deactivate an employee.
    
-   `GET /update/{id}?employeeJson={...}` - Update an employee's details.
    
-   `GET /delete/{id}` - Delete an employee.
    

## 📂 Project Structure

-   **Controller**: REST endpoints handling incoming requests.
    
    -   `DepartmentController`: Handles internal department info requests.
        
    -   `DepartmentEmployeeController`: Acts as a gateway, forwarding requests to the EmployeeApp.
        
-   **Service**: Business logic and external communication.
    
    -   `DepartmentService`: Provides static internal data.
        
    -   `DepartmentEmployeeService`: Handles read-only calls to EmployeeApp.
        
    -   `DepartmentEmployeeAdminService`: Handles state-changing calls (POST/PUT/DELETE) to EmployeeApp.
        
-   **Entities**: Data models.
    
    -   `EmployeeEntity`: Represents the employee structure used for mapping responses.
        
-   **Config**: Application configuration.
    
    -   `RestTemplateConfig`: Configures the HTTP client.
        
    -   `SwaggerConfig`: Configures OpenAPI documentation.

## How AIAnalyse Uses the Dataset

-   Identifying changed modules
    
-   Mapping changes to internal & downstream microservices
    
-   Computing direct vs indirect impacts
    
-   Evaluating DB impact paths
    
-   Building a reasoning prompt for Gemini
    
-   Producing the final Impact Analysis response with scores
    

## Data Security & Governance

-   No user data or personal information is ever processed.
    
-   All dataset components are technical metadata only.